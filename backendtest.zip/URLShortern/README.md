# URLShortern Project Setup with Bun

This project is set up using Bun, a fast all-in-one JavaScript runtime.

## Setup Process

1. **Initialize the project with Bun**

   The project was initialized using the command:

   ```
   bun init -y
   ```

   This creates the basic project structure including:

   - `index.ts` as the entry point
   - `tsconfig.json` for TypeScript configuration
   - `.gitignore` file
   - `README.md` file

2. **Install dependencies**

   Bun automatically installs dependencies and creates a lockfile.

3. **Run the project**

   To start the project, use the command:

   ```
   bun run index.ts
   ```

## Notes

- Bun provides fast runtime and package management.
- The project uses TypeScript by default.
- Modify `index.ts` to start building your application.
