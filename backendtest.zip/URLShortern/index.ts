import express from 'express';
import { createServer } from 'http';
import { Server, Socket } from 'socket.io';
import { promises as fs } from 'fs';
import path from 'path';
import crypto from 'crypto';

interface UrlData {
  [key: string]: string;
}

interface ShortenedUrlMessage {
  shortenedURL: string;
  originalURL: string;
}

interface ClientSocket extends Socket {
  clientId?: string;
}

const app = express();
const server = createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Store for URL mappings and client connections
const urlStore = new Map<string, string>();
const clientConnections = new Map<string, any>();
const pendingMessages = new Map<string, ShortenedUrlMessage[]>();

// File path for persistence
const DATA_FILE = 'url_data.json';

// Middleware
app.use(express.json());

// Serve test client
app.get('/', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'test-client.html'));
});

// Load existing data on startup
async function loadData(): Promise<void> {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        const parsed: UrlData = JSON.parse(data);
        for (const [key, value] of Object.entries(parsed)) {
            urlStore.set(key, value);
        }
        console.log('Loaded existing URL data');
    } catch (error) {
        console.log('No existing data file found, starting fresh');
    }
}

// Save data to file
async function saveData(): Promise<void> {
    try {
        const data = Object.fromEntries(urlStore);
        await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Error saving data:', error);
    }
}

// Generate random 10-character code
function generateShortCode(): string {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 10; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Socket.IO connection handler
io.on('connection', (socket: ClientSocket) => {
    const clientId = crypto.randomUUID();
    clientConnections.set(clientId, socket);
    
    console.log(`Client ${clientId} connected`);
    
    // Send client ID to client
    socket.emit('connection', { clientId });
    
    // Send any pending messages for this client
    if (pendingMessages.has(clientId)) {
        const messages = pendingMessages.get(clientId)!;
        messages.forEach(message => {
            socket.emit('shortened_url', message);
        });
        pendingMessages.delete(clientId);
    }
    
    // Handle client acknowledgments
    socket.on('ack', () => {
        console.log(`Client ${clientId} acknowledged message`);
    });
    
    // Handle client disconnect
    socket.on('disconnect', () => {
        console.log(`Client ${clientId} disconnected`);
        clientConnections.delete(clientId);
    });
    
    // Store client ID in socket object
    socket.clientId = clientId;
});

// Send message to client
function sendToClient(clientId: string, message: ShortenedUrlMessage): void {
    const client = clientConnections.get(clientId);
    
    if (client && client.connected) {
        client.emit('shortened_url', message);
        console.log(`Message sent to client ${clientId}`);
    } else {
        // Client not connected, store message for later
        if (!pendingMessages.has(clientId)) {
            pendingMessages.set(clientId, []);
        }
        pendingMessages.get(clientId)!.push(message);
        console.log(`Client ${clientId} not connected - message stored for later delivery`);
    }
}

// POST /url endpoint - URL shortening
app.post('/url', async (req, res) => {
    const { url } = req.body;
    const clientId = req.headers['x-client-id'] as string;
    
    if (!url) {
        return res.status(400).json({ error: 'URL parameter is required' });
    }
    
    if (!clientId) {
        return res.status(400).json({ error: 'x-client-id header is required' });
    }
    
    try {
        // Generate unique short code
        let shortCode: string;
        do {
            shortCode = generateShortCode();
        } while (urlStore.has(shortCode));
        
        // Create shortened URL
        const baseUrl = `http://${req.get('host')}`;
        const shortenedUrl = `${baseUrl}/${shortCode}`;
        
        // Store mapping
        urlStore.set(shortCode, url);
        
        // Persist to file asynchronously
        saveData().catch(console.error);
        
        // Send result to client via Socket.IO
        const message: ShortenedUrlMessage = {
            shortenedURL: shortenedUrl,
            originalURL: url
        };
        
        sendToClient(clientId, message);
        
        // Return success status without the shortened URL
        res.status(202).json({ message: 'URL shortening in progress' });
        
    } catch (error) {
        console.error('Error shortening URL:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /:shortCode endpoint - URL redirect
app.get('/:shortCode', (req, res) => {
    const { shortCode } = req.params;
    
    if (shortCode.length === 10 && urlStore.has(shortCode)) {
        const originalUrl = urlStore.get(shortCode)!;
        res.json({ url: originalUrl });
    } else {
        res.status(404).json({ error: 'Short URL not found' });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'OK', urls: urlStore.size });
});

// Start server
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 5000;

// Load data and start server
loadData().then(() => {
    server.listen(PORT, '0.0.0.0', () => {
        console.log(`URL shortener server running on http://0.0.0.0:${PORT}`);
        console.log('Socket.IO server ready for client connections');
    });
});
